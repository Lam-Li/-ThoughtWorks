//package tw_problem.problem2;
//
//import java.util.*;
//
//public class SortMap {
//    /**
//     *
//     * @param sourceMap (parameter) source map
//     * @return Sorted array, Key: String; Value: Integer;
//     */
//    public static Map<String, Integer> sortMapByValue(Map<String, Integer> sourceMap) {
//        //check
//        if (sourceMap == null || sourceMap.isEmpty()) {
//            return null;
//        }
//        Map<String, Integer> sortedMap = new LinkedHashMap<String, Integer>();
//        List<Map.Entry<String, Integer>> entryList = new ArrayList<Map.Entry<String, Integer>>(sourceMap.entrySet());
//        Collections.sort(entryList, new SortMapForValue());     //sort
//
//        Iterator<Map.Entry<String, Integer>> inert = entryList.iterator();
//        Map.Entry<String, Integer> tmpEntry = null;
//        while (inert.hasNext()) {
//            tmpEntry = inert.next();
//            sortedMap.put(tmpEntry.getKey(), tmpEntry.getValue());
//        }
//        return sortedMap;
//    }
//
//    static class SortMapForValue implements Comparator<Map.Entry<String, Integer>>{
//        public int compare(Map.Entry<String, Integer> o1, Map.Entry<String, Integer> o2) {
//            return o2.getValue().compareTo(o1.getValue());
//        }
//    }
//}
