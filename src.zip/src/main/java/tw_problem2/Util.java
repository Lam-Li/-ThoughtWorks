package tw_problem2;

import java.io.*;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class Util {
    /**
     * Use a tool class to take the talk title and time
     * @return Map, Key：title, Value: time
     */
    public static Map<String, Integer> readFile(){
        HashMap<String, Integer> talk = new HashMap<String, Integer>();
        File file = new File("D:\\itfimer\\src\\main\\java\\tw_problem2\\Testinput");

//        try {
//            String canonicalPath = file.getCanonicalPath();
//            System.out.println(canonicalPath);
//        } catch (IOException e) {
//            e.printStackTrace();
//        }

        BufferedReader bufferedReader = null;
        try {
            bufferedReader = new BufferedReader(new FileReader(file));
            String title;
            int time;
            while((title = bufferedReader.readLine()) != null){
                int lastBlank = title.lastIndexOf(" ");
                String talkTitle = title.substring(0, lastBlank);
                String talkTime = title.substring(lastBlank + 1);
                if (talkTime.equals("lightning")){
                    time = 5;
                }else {
                    time = Integer.parseInt(talkTime.substring(0, talkTime.length() -3));
                }
                talk.put(talkTitle, time);
            }
            bufferedReader.close();
        } catch (FileNotFoundException e) {
            System.out.println("File Not Found");
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (bufferedReader != null){
                try {
                        bufferedReader.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
            }
        }

        return talk;
    }

}
